#include "kdtree.h"
#include <csignal>

inline float u01() {
    return rand() / float( RAND_MAX );
}

void test_bisection() {
	std::vector<vector<float, 3> > pts;
	pts.emplace_back(0, 0, 0);
	pts.emplace_back(1, 0, 0);
	kdtree<float, 3, int> tree;
	tree.build(pts.data(), pts.size());
	srand(time(0));
	int s = 0;
	int nsearch = 4 * 1024 * 1024;
	printf("%d searches among %d points:\n", nsearch, pts.size());
	double b, e;
	b = get_time_posix();
	for (std::size_t c = 0; c < nsearch; c++) {
		vector<float, 3> q(u01(), u01(), u01());
		//vector<float,3> q( 0.362004101, 0.5912444, 0.846240699 );
		float r1, r2;
		std::size_t p1, p2;
		std::tie(r2, p2) = tree.find_nearest(q);
		p1 = ((q[0] > 0.5) ? 1 : 0);
		if (p1 != p2) {
			raise(SIGSEGV);
		}
	}
	e = get_time_posix();
	printf("kd tree +IG %.3lf seconds\n", e - b);
}

void test_random() {
	auto L = 28;
	std::vector<vector<float, 3> > pts;
	for (int i = 0; i <= L; i++)
		for (int j = 0; j <= L; j++)
			for (int k = 0; k <= L; k++)
				pts.emplace_back(u01() * L, u01() * L, u01() * L);
	kdtree<float, 3, int> tree;
	tree.build(pts.data(), pts.size());
	srand(time(0));
	int s = 0;
	int nsearch = 4 * 1024 * 1024;
	printf("%d searches among %d points:\n", nsearch, pts.size());
	double b, e;
	b = get_time_posix();
	for (std::size_t c = 0; c < nsearch; c++) {
		vector<float, 3> q(u01() * L, u01() * L, u01() * L);
		float r1, r2;
		std::size_t p1, p2;
		std::tie(r2, p2) = tree.find_nearest(q, std::make_tuple(1.0,-1) );
		s += p2;
	}
	e = get_time_posix();
	printf("kd tree +IG %.3lf seconds\n", e - b);
}

void test_find_within() {
	auto L = 60;
	std::vector<vector<float, 3> > pts;
	for (int i = 0; i <= L; i++)
		for (int j = 0; j <= L; j++)
			for (int k = 0; k <= L; k++)
				pts.emplace_back( i, j, k );
	kdtree<float, 3, int> tree;
	tree.build(pts.data(), pts.size());
	srand(time(0));
	int s = 0;
	int nsearch = pts.size();
	printf("%d find_within among %d points:\n", nsearch, pts.size());
	double b, e;
	b = get_time_posix();
	const static float max_r = 1.5;
	const static int nmax = 64;
	int neighbor[nmax];
	for (std::size_t c = 0; c < nsearch; c++) {
		vector<float, 3> q(u01() * L, u01() * L, u01() * L);
		auto nneighbor = tree.find_within(q, max_r, neighbor, nmax );
		for( int i=0;i<nneighbor;i++) {
			assert( normsq( q - pts[ neighbor[i] ] ) <= max_r * max_r );
		}
	}
	e = get_time_posix();
	printf("kd tree +IG %.3lf seconds\n", e - b);
}

int main() {
	test_random();
	test_bisection();
	test_find_within();

	return 0;
}
