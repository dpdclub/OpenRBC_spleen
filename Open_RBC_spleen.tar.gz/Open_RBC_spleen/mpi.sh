#!/bin/bash                                                                                                                

# Request an hour of runtime:                                                                                               
#SBATCH --time=58:00:00                                                                                                     
# Use 2 nodes with 8 tasks each, for 16 MPI tasks:                                                                          
#SBATCH --nodes=1                                                                                                           
#SBATCH --tasks-per-node=16                                                                                             

# Specify a job name:                                                                                                       
#SBATCH -J MyMPIJob                                                                                                         

# Specify an output file                                                                                                    
#SBATCH -o MyMPIJob-%j.out                                                                                                  


# Run a command                                                                                                             


#mpirun -n 12 ./FCM_DIPOLE step.conf                                                                                        
OMP_NUM_THREADS=16 ./openrbc -i trimesh -m rbc  -E 1000 -t 400000 -d 200000 |tee 1.log
