#!/bin/bash

for f in $(ls *.h openrbc.cpp); do
    yt=$(svn blame $f | grep ytang | wc -l)
    ll=$(svn blame $f | grep ll    | wc -l)
    echo $f
    cat > tmp << EOF
/******************************************************************************
!@ This file is part of the OpenRBC code for protein-resolution red blood cells
!@ Copyright author(s):
!@ Yu-Hang Tang    $(printf "% 4d" $yt) lines of code
!@ Lu Lu           $(printf "% 4d" $ll) lines of code
!@ 2016 All rights reserved.
******************************************************************************/
EOF

cat tmp $f > $f.tmp
mv $f.tmp $f

done
