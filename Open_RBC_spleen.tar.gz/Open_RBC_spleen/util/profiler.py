import cProfile
import pstats
#import rbc_mesh

cProfile.run( open('rbc_mesh.py'), 'restats' )
p = pstats.Stats( 'restats' )
p.sort_stats( 'cumulative' ).print_stats(10)
