/******************************************************************************
!@ This file is part of the OpenRBC code for protein-resolution red blood cells
!@ Copyright (c) 2016 Yu-Hang Tang, Lu Lu
!@ Licensed under the Apache License, Version 2.0 (the "License")
!@ you may not use this file except in compliance with the License.
!@ You may obtain a copy of the License at
!@             http://www.apache.org/licenses/LICENSE-2.0
!@ Unless required by applicable law or agreed to in writing, software
!@ distributed under the License is distributed on an "AS IS" BASIS,
!@ WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
!@ See the License for the specific language governing permissions and
!@ limitations under the License.
******************************************************************************/
#ifndef OPENRBC_SPLEEN_H_
#define OPENRBC_SPLEEN_H_

#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include "config_static.h"
#include "math_vector.h"
#include "util_misc.h"

namespace openrbc {

using namespace config;

template<uint DIM>
struct wall_flat {
    wall_flat(const real coord_) : coord(coord_) {}

    inline bool reflect_lo(vect & x, vect & v) const {
        if (x[DIM] >= coord) return false;
        x[DIM] = constant::two * coord - x[DIM];
        v[DIM] *= -constant::one;
        return true;
    }

    inline bool reflect_hi(vect & x, vect & v) const {
        if (x[DIM] <= coord) return false;
        x[DIM] = constant::two * coord - x[DIM];
        v[DIM] *= -constant::one;
        return true;
    }

    real coord;
};

template<uint DIM1, uint DIM2>
struct wall_halfflat {
    wall_halfflat(const real coord1_, const real coord2_) : coord1(coord1_), coord2(coord2_) {}

    wall_halfflat(const real coord1_, const real coord2_, const real epsilon_, const real sigma_, const real cutoff_) :
            coord1(coord1_), coord2(coord2_), epsilon(epsilon_), sigma(sigma_), cutoff(cutoff_) {
        coeff1 = 48 * epsilon * pow(sigma, 12);
        coeff2 = 24 * epsilon * pow(sigma, 6);
    }

    // wall/reflect

    inline bool hi_reflect_lo(vect & x, vect & v) const {
        if (x[DIM1] >= coord1 || x[DIM2] <= coord2) return false;
        x[DIM1] = constant::two * coord1 - x[DIM1];
        v[DIM1] *= -constant::one;
        return true;
    }

    inline bool hi_reflect_hi(vect & x, vect & v) const {
        if (x[DIM1] <= coord1 || x[DIM2] <= coord2) return false;
        x[DIM1] = constant::two * coord1 - x[DIM1];
        v[DIM1] *= -constant::one;
        return true;
    }

    inline bool lo_reflect_lo(vect & x, vect & v) const {
        if (x[DIM1] >= coord1 || x[DIM2] >= coord2) return false;
        x[DIM1] = constant::two * coord1 - x[DIM1];
        v[DIM1] *= -constant::one;
        return true;
    }

    inline bool lo_reflect_hi(vect & x, vect & v) const {
        if (x[DIM1] <= coord1 || x[DIM2] >= coord2) return false;
        x[DIM1] = constant::two * coord1 - x[DIM1];
        v[DIM1] *= -constant::one;
        return true;
    }

    // wall/lj126

    inline real wall_force(const real delta) const {
        rt_assert(delta > 0, "Particle on or inside halfwall surface");
        const real rinv = constant::one / delta;
        const real r2inv = rinv * rinv;
        const real r6inv = r2inv * r2inv * r2inv;
        return r6inv * (coeff1 * r6inv - coeff2) * rinv;
    }

    inline bool hi_lj126_lo(const vect & x, vect & f) const {
        const real delta = x[DIM1] - coord1;
        if (delta >= cutoff || x[DIM2] <= coord2 || delta < -cutoff) return false;
        f[DIM1] += wall_force(delta);
        return true;
    }

    inline bool hi_lj126_hi(const vect & x, vect & f) const {
        const real delta = coord1 - x[DIM1];
        if (delta >= cutoff || x[DIM2] <= coord2 || delta < -cutoff) return false;
        f[DIM1] -= wall_force(delta);
        return true;
    }

    inline bool lo_lj126_lo(const vect & x, vect & f) const {
        const real delta = x[DIM1] - coord1;
        if (delta >= cutoff || x[DIM2] >= coord2 || delta < -cutoff) return false;
        f[DIM1] += wall_force(delta);
        return true;
    }

    inline bool lo_lj126_hi(const vect & x, vect & f) const {
        const real delta = coord1 - x[DIM1];
        if (delta >= cutoff || x[DIM2] >= coord2 || delta < -cutoff) return false;
        f[DIM1] -= wall_force(delta);
        return true;
    }

    real coord1, coord2;
    real epsilon, sigma, cutoff;
    real coeff1, coeff2;
};

template<uint DIM1, uint DIM2>
struct wall_finiteflat {
    wall_finiteflat(const real coord1_, const real coord2_, const real coord3_, const real epsilon_, const real sigma_, const real cutoff_) :
            coord1(coord1_), coord2(coord2_), coord3(coord3_), epsilon(epsilon_), sigma(sigma_), cutoff(cutoff_) {
        if (coord2 > coord3) std::swap(coord2, coord3);
        coeff1 = 48 * epsilon * pow(sigma, 12);
        coeff2 = 24 * epsilon * pow(sigma, 6);
    }

    // wall/lj126

    inline real wall_force(const real delta) const {
        rt_assert(delta > 0, "Particle on or inside halfwall surface");
        const real rinv = constant::one / delta;
        const real r2inv = rinv * rinv;
        const real r6inv = r2inv * r2inv * r2inv;
        return r6inv * (coeff1 * r6inv - coeff2) * rinv;
    }

    inline bool lj126_lo(const vect & x, vect & f) const {
        const real delta = x[DIM1] - coord1;
        if (delta >= cutoff || x[DIM2] <= coord2 || x[DIM2] >= coord3 || delta < -cutoff) return false;
        f[DIM1] += wall_force(delta);
        return true;
    }

    inline bool lj126_hi(const vect & x, vect & f) const {
        const real delta = coord1 - x[DIM1];
        if (delta >= cutoff || x[DIM2] <= coord2 || x[DIM2] >= coord3 || delta < -cutoff) return false;
        f[DIM1] -= wall_force(delta);
        return true;
    }

    real coord1, coord2, coord3;
    real epsilon, sigma, cutoff;
    real coeff1, coeff2;
};

struct wall_sphere {
    wall_sphere(const vect & c_, const real r_) : c(c_), r(r_) {rsq = r * r;}

    wall_sphere(const vect & c_, const real r_, const real epsilon_, const real sigma_, const real cutoff_) :
            c(c_), r(r_), epsilon(epsilon_), sigma(sigma_), cutoff(cutoff_) {
        rsq = r * r;
        coeff1 = 48 * epsilon * pow(sigma, 12);
        coeff2 = 24 * epsilon * pow(sigma, 6);
    }

    inline bool reflect(vect & x, vect & v) const {
        const vect xc = x - c;
        const real lsq = normsq(xc);
        if (lsq >= rsq) return false;
        const real l = std::sqrt(lsq);
        x = c + (constant::two * r / l - constant::one) * xc;
        const vect norm_xc = xc / l;
        const vect vc = dot(v, norm_xc) * norm_xc;
        v -= constant::two * vc;
        return true;
    }

    inline bool lj126(const vect & x, vect & f) const {
        const vect xc = x - c;
        const real l = norm(xc);
        const real delta = l - r;
        if (delta >= cutoff) return false;
        rt_assert(delta > 0, "Particle on or inside sphere surface");
        const real rinv = constant::one / delta;
        const real r2inv = rinv * rinv;
        const real r6inv = r2inv * r2inv * r2inv;
        const real fwall = r6inv * (coeff1 * r6inv - coeff2) * rinv;
        f +=  fwall * xc / l;
        return true;
    }

    vect c;
    real r, rsq;
    real epsilon, sigma, cutoff;
    real coeff1, coeff2;
};

template<uint DIM>
struct wall_cylinder {
    wall_cylinder(const vect & c_, const real r_, const real epsilon_, const real sigma_, const real cutoff_) :
            c(c_), r(r_), epsilon(epsilon_), sigma(sigma_), cutoff(cutoff_) {
        rsq = r * r;
        coeff1 = 48 * epsilon * pow(sigma, 12);
        coeff2 = 24 * epsilon * pow(sigma, 6);
    }

    inline bool lj126(const vect & x, vect & f) const {
        vect c0 = c;
        c0[DIM] = x[DIM];
        const vect xc = x - c0;
        const real l = norm(xc);
        const real delta = l - r;
        if (delta >= cutoff) return false;
        rt_assert(delta > 0, "Particle on or inside cylinder surface");
        const real rinv = constant::one / delta;
        const real r2inv = rinv * rinv;
        const real r6inv = r2inv * r2inv * r2inv;
        const real fwall = r6inv * (coeff1 * r6inv - coeff2) * rinv;
        f +=  fwall * xc / l;
        return true;
    }

    vect c;
    real r, rsq;
    real epsilon, sigma, cutoff;
    real coeff1, coeff2;
};

struct spleen {
    spleen(const vect & center, real height, real depth, real ws_, real wf_, real epsilon_, real sigma_, real cutoff_) :
            c(center), h(height), d(depth), ws(ws_), wf(wf_), epsilon(epsilon_), sigma(sigma_), cutoff(cutoff_),
            halfflat{{c[1] - d / 2, c[2] + h / 2 + d / 2, epsilon, sigma, cutoff},
                     {c[1] - d / 2, c[2] - h / 2 - d / 2, epsilon, sigma, cutoff},
                     {c[1] + d / 2, c[2] + h / 2 + d / 2, epsilon, sigma, cutoff},
                     {c[1] + d / 2, c[2] - h / 2 - d / 2, epsilon, sigma, cutoff}},
            cylinder{{c + vect(0, 0, h / 2 + d / 2, 0), d / 2, epsilon, sigma, cutoff},
                     {c - vect(0, 0, h / 2 + d / 2, 0), d / 2, epsilon, sigma, cutoff}},
            finiteflat{{ws / 2, c[1] - d / 2 + wf / 2, c[1] + d / 2 - wf / 2, epsilon, sigma, cutoff},
                        {ws / 2 + wf, c[1] - d / 2 + wf / 2, c[1] + d / 2 - wf / 2, epsilon, sigma, cutoff},
                        {-ws / 2, c[1] - d / 2 + wf / 2, c[1] + d / 2 - wf / 2, epsilon, sigma, cutoff},
                        {-ws / 2 - wf, c[1] - d / 2 + wf / 2, c[1] + d / 2 - wf / 2, epsilon, sigma, cutoff}},
            cylinder2{{{ws / 2 + wf / 2, c[1] - d / 2 + wf / 2, 0, 0}, wf / 2, epsilon, sigma, cutoff},
                      {{ws / 2 + wf / 2, c[1] + d / 2 - wf / 2, 0, 0}, wf / 2, epsilon, sigma, cutoff},
                      {{-ws / 2 - wf / 2, c[1] - d / 2 + wf / 2, 0, 0}, wf / 2, epsilon, sigma, cutoff},
                      {{-ws / 2 - wf / 2, c[1] + d / 2 - wf / 2, 0, 0}, wf / 2, epsilon, sigma, cutoff}} {
        rt_assert(d > wf, "Wrong spleen geometry");
        save_spleen();
    }

    static std::string name() { return "spleen"; }

    template<class CONTAINER>
    void operator () (CONTAINER &container, int beg, int end) const {
        for (int i = beg; i < end; ++i) {
            if (halfflat[0].hi_lj126_hi(container.x[i], container.f[i])) continue;
            if (halfflat[1].lo_lj126_hi(container.x[i], container.f[i])) continue;
            if (halfflat[2].hi_lj126_lo(container.x[i], container.f[i])) continue;
            if (halfflat[3].lo_lj126_lo(container.x[i], container.f[i])) continue;
            cylinder[0].lj126(container.x[i], container.f[i]);
            cylinder[1].lj126(container.x[i], container.f[i]);
            finiteflat[0].lj126_hi(container.x[i], container.f[i]);
            finiteflat[1].lj126_lo(container.x[i], container.f[i]);
            finiteflat[2].lj126_lo(container.x[i], container.f[i]);
            finiteflat[3].lj126_hi(container.x[i], container.f[i]);
            cylinder2[0].lj126(container.x[i], container.f[i]);
            cylinder2[1].lj126(container.x[i], container.f[i]);
            cylinder2[2].lj126(container.x[i], container.f[i]);
            cylinder2[3].lj126(container.x[i], container.f[i]);
        }
    }

    void save_spleen() {
        real l = 1.5 * ws + wf;
        std::ostringstream atoms;
        int tag = 1;
        for (int i = 0; i < 2; ++i)
            for (real x = cylinder[i].c[0]; x < l; x += cylinder[i].r / 16) {
                atoms << tag++ << " 1 " << x << ' ' << cylinder[i].c[1] << ' ' << cylinder[i].c[2] << '\n';
                atoms << tag++ << " 1 " << -x << ' ' << cylinder[i].c[1] << ' ' << cylinder[i].c[2] << '\n';
            }
        dump_spleen("spleen_a.lammpstrj", atoms, tag - 1);

        tag = 1;
        for (int i = 0; i < 4; ++i)
            for (real z = cylinder2[i].c[2]; z < cylinder[0].c[2] + cylinder[0].r; z += cylinder2[i].r * 2) {
                atoms << tag++ << " 1 " << cylinder2[i].c[0] << ' ' << cylinder2[i].c[1] << ' ' << z << '\n';
                atoms << tag++ << " 1 " << cylinder2[i].c[0] << ' ' << cylinder2[i].c[1] << ' ' << -z << '\n';
            }
        dump_spleen("spleen_b.lammpstrj", atoms, tag - 1);

        tag = 1;
        for (int i = 0; i < 2; ++i)
            for (real x = cylinder[i].c[0]; x < l; x += cylinder[i].r * 2) {
                atoms << tag++ << " 1 " << x << ' ' << cylinder[i].c[1] << ' ' << cylinder[i].c[2] + cylinder[i].r * cylinder[i].c[2] / abs(cylinder[i].c[2]) << '\n';
                atoms << tag++ << " 1 " << -x << ' ' << cylinder[i].c[1] << ' ' << cylinder[i].c[2] + cylinder[i].r * cylinder[i].c[2] / abs(cylinder[i].c[2]) << '\n';
            }
        for (int i = 0; i < 4; i += 2)
            for (real z = cylinder2[i].c[2]; z < cylinder[0].c[2] + cylinder[0].r ; z += cylinder2[i].r * 2) {
                atoms << tag++ << " 2 " << cylinder2[i].c[0] << ' ' << (cylinder2[i].c[1] + cylinder2[i + 1].c[1]) / 2 << ' ' << z << '\n';
                atoms << tag++ << " 2 " << cylinder2[i].c[0] << ' ' << (cylinder2[i].c[1] + cylinder2[i + 1].c[1]) / 2 << ' ' << -z << '\n';
            }
        dump_spleen("spleen_c.lammpstrj", atoms, tag - 1);
    }

    void dump_spleen(const std::string file, std::ostringstream & atoms, const int n) {
        std::ofstream fout(file);
        fout << "ITEM: TIMESTEP\n"
             << "0\n"
             << "ITEM: NUMBER OF ATOMS\n"
             << n << "\n"
             << "ITEM: BOX BOUNDS ff ff ff\n"
             << "-1000 1000\n"
             << "-1000 1000\n"
             << "-1000 1000\n"
             << "ITEM: ATOMS id type xu yu zu\n";
        fout << atoms.str();
        fout.close();
        atoms.clear();
        atoms.str("");
    }

    vect c;
    real h, d;
    real ws, wf;
    real epsilon, sigma, cutoff;

    wall_halfflat<1, 2> halfflat[4];
    wall_cylinder<0> cylinder[2];
    wall_finiteflat<0, 1> finiteflat[4];
    wall_cylinder<2> cylinder2[4];
};

}

#endif