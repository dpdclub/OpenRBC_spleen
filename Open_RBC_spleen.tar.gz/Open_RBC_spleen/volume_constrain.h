/******************************************************************************
!@ This file is part of the OpenRBC code for protein-resolution red blood cells
!@ Copyright (c) 2016 Yu-Hang Tang, Lu Lu
!@ Licensed under the Apache License, Version 2.0 (the "License")
!@ you may not use this file except in compliance with the License.
!@ You may obtain a copy of the License at
!@             http://www.apache.org/licenses/LICENSE-2.0
!@ Unless required by applicable law or agreed to in writing, software
!@ distributed under the License is distributed on an "AS IS" BASIS,
!@ WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
!@ See the License for the specific language governing permissions and
!@ limitations under the License.
******************************************************************************/
#ifndef OPENRBC_VOLUME_CONSTRAIN_H_
#define OPENRBC_VOLUME_CONSTRAIN_H_

#include <cmath>
#include "aligned_array.h"
#include "integrate_nh.h"
#include "math_vector.h"
#include "runtime_parameter.h"
#include "voronoi.h"

namespace openrbc {

using namespace config;

//-------------------------- Kernel --------------------------
struct volume_constrain {

    volume_constrain( VoronoiDiagram & voronoi_, VCellList & cell_list_, RTParameter & p, double & f_ ) :
        voronoi( voronoi_ ), cell_list( cell_list_ ), parameter( p ), f(f_) {}

    static std::string name() { return "volume_constrain"; }

    template<class CONTAINER>
    void operator () (CONTAINER &container, int beg, int end) {
        double volume_force = 0;
        if (f == 0) {
            const int cell_beg = voronoi.load_balancer().beg();
            const int cell_end = voronoi.load_balancer().end();

            vector<real, 3> local_center = 0;
            for (int i = cell_beg; i < cell_end; ++i) local_center += voronoi.centroids[i] * 1e-3;
            #pragma omp master
            {
                global_center = 0;
            }
            #pragma omp barrier
            #pragma omp critical
            {
                global_center += local_center;
            }
            #pragma omp barrier
            #pragma omp master
            {
                global_center *= 1e3;
                global_center /= voronoi.n_cells;
                global_volume = 0;
            }
            #pragma omp barrier

            real local_volume = 0;
            for (int i = cell_beg; i < cell_end; ++i) {
                vector<real, 3> local_normal = 0;
                real cell_radius = 0;
                for (int j = cell_list.cell_start[i]; j < cell_list.cell_start[i + 1]; ++j) {
                    vector<real, 3> radius;
                    for (int k = 0; k < 3; ++k) {
                        local_normal[k] += container.n[j][k];
                        radius[k] = container.x[j][k] - voronoi.centroids[i][k];
                    }
                    cell_radius += norm(radius);
                }

                cell_radius /= cell_list.cell_start[i + 1] - cell_list.cell_start[i];
                local_normal = normalize(local_normal);

                const vector<real, 3> distance = voronoi.centroids[i] - global_center;
                const real local_cell_distance = abs(dot(distance, local_normal));
                local_volume += local_cell_distance * (cell_list.cell_start[i + 1] - cell_list.cell_start[i]) * 3.1415926 * 1.26 / 4.0 / 3.0 * 1e-6;
                // BUG: cell_radius
                // local_volume += local_cell_distance * 3.1415926 * cell_radius * cell_radius / 3.0 * 1e-6;
            }
            #pragma omp atomic
            global_volume += local_volume;
            #pragma omp barrier


            // const real volume_force = -100000.* (global_volume - target_volume)/target_volume/container.size();
            //f = -0.1 * (global_volume - target_volume) / target_volume;
            f = -0.2 * (global_volume - target_volume) / target_volume;

            for (int i = beg; i < end; ++i) {
                vector<real, 3> normal_direction;
                // for (int k = 0; k < 3; ++k) normal_direction[k] = container.x[i][k] - global_center[k];
                for (int k = 0; k < 3; ++k) normal_direction[k] = container.n[i][k];
                normal_direction = normalize(normal_direction);
                for (int k = 0; k < 3; ++k) container.f[i][k] += f * normal_direction[k];
            }

            #pragma omp master
            {
                if (parameter.nstep % 1000 == 0)
                    fprintf(stdout, "target_volume=%lf, global_volume=%f volume_force=%f\n", target_volume, global_volume, f);
            }
        } else {
            // f != 0
            for (int i = beg; i < end; ++i) {
                vector<real, 3> normal_direction;
                // for (int k = 0; k < 3; ++k) normal_direction[k] = container.x[i][k] - global_center[k];
                for (int k = 0; k < 3; ++k) normal_direction[k] = container.n[i][k];
                normal_direction = normalize(normal_direction);
                for (int k = 0; k < 3; ++k) container.f[i][k] += f * normal_direction[k];
            }
        }
    }
  
    static constexpr real target_volume = 3.;

    real global_volume = 0;
    vector<real, 3> global_center;

    VoronoiDiagram & voronoi;
    VCellList & cell_list;
    RTParameter & parameter;
    double &f;
};

}

#endif
